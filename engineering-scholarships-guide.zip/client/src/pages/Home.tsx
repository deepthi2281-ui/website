/**
 * Global Engineering Scholarships Guide - Home Page
 * Design: Academic Modernism
 * - Deep navy blues (#0A1628, #1E3A5F) with warm amber accents (#F59E0B)
 * - Asymmetric card-based grid with magazine-style layout
 * - Playfair Display for headings, Inter for body
 * - Floating scholarship cards with elevation and hover effects
 */

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  GraduationCap, 
  Globe, 
  Search, 
  MapPin, 
  Calendar, 
  DollarSign, 
  BookOpen,
  TrendingUp,
  Users,
  Award,
  ArrowRight,
  ExternalLink
} from "lucide-react";

interface ScholarshipData {
  engineeringBranches: Array<{
    name: string;
    description: string;
    suitability: string;
    careerProspects: string;
  }>;
  scholarshipsByRegion: {
    [key: string]: Array<{
      name: string;
      country: string;
      university: string;
      level: string;
      coverage: string;
      eligibility: string;
      deadline: string;
      website: string;
    }>;
  };
  topUniversities: Array<{
    name: string;
    country: string;
    ranking: number;
    strengths: string[];
    financialAid: string;
    website: string;
  }>;
  applicationTips: string[];
}

export default function Home() {
  const [data, setData] = useState<ScholarshipData | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegion, setSelectedRegion] = useState<string>("all");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");

  useEffect(() => {
    fetch("/scholarships_data.json")
      .then((res) => res.json())
      .then((jsonData) => setData(jsonData))
      .catch((err) => console.error("Failed to load scholarship data:", err));
  }, []);

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading scholarship data...</p>
        </div>
      </div>
    );
  }

  const regions = ["all", ...Object.keys(data.scholarshipsByRegion)];
  
  const filteredScholarships = Object.entries(data.scholarshipsByRegion)
    .filter(([region]) => selectedRegion === "all" || region === selectedRegion)
    .flatMap(([region, scholarships]) =>
      scholarships
        .filter((s) => {
          const matchesLevel = selectedLevel === "all" || s.level.toLowerCase().includes(selectedLevel.toLowerCase());
          const matchesSearch = searchQuery === "" || 
            s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            s.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
            s.university.toLowerCase().includes(searchQuery.toLowerCase());
          return matchesLevel && matchesSearch;
        })
        .map((s) => ({ ...s, region }))
    );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - Diagonal Split */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/95 to-primary/90 text-primary-foreground">
        <div className="absolute inset-0 opacity-10">
          <img 
            src="/images/hero-students.jpg" 
            alt="Engineering students collaborating" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="container relative py-20 lg:py-32">
          <div className="max-w-3xl">
            <Badge className="mb-4 bg-accent text-accent-foreground hover:bg-accent/90">
              <Globe className="w-3 h-3 mr-1" />
              Global Opportunities
            </Badge>
            <h1 className="text-5xl lg:text-7xl font-display font-bold mb-6 leading-tight">
              Engineering Scholarships Worldwide
            </h1>
            <p className="text-xl lg:text-2xl mb-8 text-primary-foreground/90 font-medium">
              Comprehensive guide to undergraduate engineering programs and scholarships for PCM + Computer Science students after Grade 12
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                className="bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg hover:shadow-xl transition-all"
                onClick={() => document.getElementById('scholarships')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Explore Scholarships
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/20"
                onClick={() => document.getElementById('programs')?.scrollIntoView({ behavior: 'smooth' })}
              >
                View Programs
              </Button>
            </div>
          </div>
        </div>
        {/* Diagonal bottom edge */}
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-background" style={{ clipPath: 'polygon(0 100%, 100% 0, 100% 100%, 0 100%)' }}></div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <Card className="text-center border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                  <Award className="w-8 h-8" />
                </div>
                <div className="text-4xl font-display font-bold text-primary mb-2">150+</div>
                <p className="text-muted-foreground font-medium">Scholarship Programs</p>
              </CardContent>
            </Card>
            <Card className="text-center border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 text-accent mb-4">
                  <Globe className="w-8 h-8" />
                </div>
                <div className="text-4xl font-display font-bold text-accent mb-2">50+</div>
                <p className="text-muted-foreground font-medium">Countries Covered</p>
              </CardContent>
            </Card>
            <Card className="text-center border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                  <GraduationCap className="w-8 h-8" />
                </div>
                <div className="text-4xl font-display font-bold text-primary mb-2">12</div>
                <p className="text-muted-foreground font-medium">Engineering Branches</p>
              </CardContent>
            </Card>
            <Card className="text-center border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 text-accent mb-4">
                  <Users className="w-8 h-8" />
                </div>
                <div className="text-4xl font-display font-bold text-accent mb-2">100K+</div>
                <p className="text-muted-foreground font-medium">Students Helped</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Engineering Branches Section */}
      <section id="programs" className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-primary/10 text-primary hover:bg-primary/20">
              <BookOpen className="w-3 h-3 mr-1" />
              Engineering Programs
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-display font-bold mb-4">
              Engineering Branches for PCM + CS Students
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Explore diverse engineering specializations perfectly suited for students with Physics, Chemistry, Mathematics, and Computer Science background
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.engineeringBranches.map((branch, idx) => (
              <Card 
                key={idx} 
                className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border/50"
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground font-bold text-xl">
                      {branch.name.charAt(0)}
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {branch.suitability}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-display">{branch.name}</CardTitle>
                  <CardDescription className="text-sm">{branch.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <TrendingUp className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-muted-foreground">{branch.careerProspects}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Scholarships Section */}
      <section id="scholarships" className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-accent/10 text-accent hover:bg-accent/20">
              <Award className="w-3 h-3 mr-1" />
              Scholarship Opportunities
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-display font-bold mb-4">
              Find Your Perfect Scholarship
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Browse through {filteredScholarships.length}+ scholarship opportunities across the globe
            </p>
          </div>

          {/* Filters */}
          <Card className="mb-8 border-border/50 shadow-md">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search scholarships, universities, countries..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map((region) => (
                      <SelectItem key={region} value={region}>
                        {region === "all" ? "All Regions" : region}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="undergraduate">Undergraduate</SelectItem>
                    <SelectItem value="bachelor">Bachelor's</SelectItem>
                    <SelectItem value="master">Master's</SelectItem>
                    <SelectItem value="phd">PhD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Scholarship Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredScholarships.map((scholarship, idx) => (
              <Card 
                key={idx} 
                className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border/50"
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
                      {scholarship.region}
                    </Badge>
                    <Badge variant="outline" className="font-mono text-xs">
                      {scholarship.level}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-display leading-tight">
                    {scholarship.name}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {scholarship.university}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-accent flex-shrink-0" />
                    <span className="font-medium">{scholarship.country}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <DollarSign className="w-4 h-4 text-accent flex-shrink-0" />
                    <span className="text-muted-foreground">{scholarship.coverage}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-accent flex-shrink-0" />
                    <span className="text-muted-foreground">Deadline: {scholarship.deadline}</span>
                  </div>
                  <div className="pt-2 border-t border-border/50">
                    <p className="text-sm text-muted-foreground mb-3">
                      <span className="font-semibold text-foreground">Eligibility:</span> {scholarship.eligibility}
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full group"
                      onClick={() => window.open(scholarship.website, '_blank')}
                    >
                      Learn More
                      <ExternalLink className="ml-2 h-3 w-3 group-hover:translate-x-0.5 transition-transform" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredScholarships.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No scholarships found matching your criteria. Try adjusting your filters.</p>
            </div>
          )}
        </div>
      </section>

      {/* Top Universities Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-primary/10 text-primary hover:bg-primary/20">
              <GraduationCap className="w-3 h-3 mr-1" />
              Top Institutions
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-display font-bold mb-4">
              World's Leading Engineering Universities
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Prestigious institutions offering exceptional engineering programs and financial aid
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {data.topUniversities.map((uni, idx) => (
              <Card 
                key={idx} 
                className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border/50"
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground font-bold font-mono">
                        #{uni.ranking}
                      </div>
                      <div>
                        <CardTitle className="text-lg font-display leading-tight">
                          {uni.name}
                        </CardTitle>
                        <CardDescription className="text-sm flex items-center gap-1 mt-1">
                          <MapPin className="w-3 h-3" />
                          {uni.country}
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-2">Strengths:</p>
                    <div className="flex flex-wrap gap-2">
                      {uni.strengths.map((strength, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">
                          {strength}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="pt-2 border-t border-border/50">
                    <p className="text-sm text-muted-foreground mb-3">
                      <span className="font-semibold text-foreground">Financial Aid:</span> {uni.financialAid}
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full group"
                      onClick={() => window.open(uni.website, '_blank')}
                    >
                      Visit Website
                      <ExternalLink className="ml-2 h-3 w-3 group-hover:translate-x-0.5 transition-transform" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Tips Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-accent/10 text-accent hover:bg-accent/20">
                <TrendingUp className="w-3 h-3 mr-1" />
                Success Tips
              </Badge>
              <h2 className="text-4xl lg:text-5xl font-display font-bold mb-4">
                Application Tips & Best Practices
              </h2>
              <p className="text-xl text-muted-foreground">
                Expert guidance to maximize your scholarship application success
              </p>
            </div>

            <Card className="border-border/50 shadow-lg">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.applicationTips.map((tip, idx) => (
                    <div 
                      key={idx} 
                      className="flex items-start gap-3 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                    >
                      <div className="w-6 h-6 rounded-full bg-accent/20 text-accent flex items-center justify-center flex-shrink-0 font-mono text-sm font-bold mt-0.5">
                        {idx + 1}
                      </div>
                      <p className="text-sm text-foreground">{tip}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-primary text-primary-foreground">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-display font-bold mb-4">Global Engineering Scholarships</h3>
              <p className="text-primary-foreground/80">
                Your comprehensive guide to engineering education opportunities worldwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-primary-foreground/80">
                <li><a href="#programs" className="hover:text-accent transition-colors">Engineering Programs</a></li>
                <li><a href="#scholarships" className="hover:text-accent transition-colors">Scholarships</a></li>
                <li><a href="/scholarships_data.json" target="_blank" className="hover:text-accent transition-colors">Download Data</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-primary-foreground/80">
                <li><a href="/engineering_scholarships_research.md" target="_blank" className="hover:text-accent transition-colors">Research Notes</a></li>
                <li className="text-primary-foreground/60">Updated: January 2026</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-primary-foreground/20 pt-8 text-center text-primary-foreground/60">
            <p>© 2026 Global Engineering Scholarships Guide. Information compiled from official sources.</p>
            <p className="mt-2 text-sm">Always verify scholarship details and deadlines on official university websites.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
