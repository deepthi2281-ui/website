# Engineering Scholarships Research - Key Findings

## Overview
Research on undergraduate engineering courses worldwide for PCM + Computer Science students after grade 12 with scholarship opportunities.

## Key Engineering Branches for PCM + CS Students
1. Computer Science Engineering (CSE)
2. Software Engineering
3. Computer Engineering
4. Electronics and Communication Engineering (ECE)
5. Information Technology
6. Data Science and Engineering
7. Artificial Intelligence and Machine Learning
8. Cybersecurity Engineering
9. Electrical Engineering
10. Mechanical Engineering
11. Aerospace Engineering
12. Civil Engineering

## ASIA - Scholarships and Programs

### Singapore
- **NUS Science & Technology Undergraduate Scholarship**: For outstanding undergraduate students from all Asian countries excluding Singapore. Covers tuition fees, compulsory fees, living costs and more. No separate application required.
- **NTU University Engineering Scholarship**: For undergraduate engineering students at Nanyang Technological University (NTU). Only open to Singapore citizens or permanent residents.

### Malaysia
- **Shell Malaysia Scholarship**: Supports A-level and undergraduate students in prestigious colleges and universities locally and overseas. Subject to scholastic performance.
- **Gamuda Scholarship**: Up to 100% tuition fee waiver for students with proof of financial need. Students required to work with Gamuda Group upon graduation.

## EUROPE - Scholarships and Programs

### Germany
**Technical University of Munich (TUM)**
- **Tuition Status**: FREE for students from Germany, EEA countries, or those who obtained undergraduate degree in German education system
- **For Non-EU International Students**: Tuition fees apply from Winter 2024/25
  - Bachelor's programs: €2,000-€3,000 per semester
  - Master's programs: €4,000-€6,000 per semester
- **Scholarships and Waivers**: Available for international students
- **Engineering Programs Available**: Computer Science, Electrical Engineering, Mechanical Engineering, Aerospace, Chemical Engineering, Civil Engineering, and more

**Other German Universities**
- Many public universities in Germany offer free or low-cost tuition for international students
- RWTH Aachen, TU Berlin, TU Dresden also offer engineering programs

### Netherlands
- **TU Delft Excellence Scholarships**: For geosciences and civil engineering students at master's level
- **University of Twente Scholarships (UTS)**: Master's degree scholarships. Deadline: 1 Feb/1 May 2026
- **NL Scholarship for Non-EEA International Students**: For Bachelor's/Master's degree. Deadline: 1 Feb/1 May 2026

### Belgium
- **Université Catholique de Louvain International Lhoist Berghmans Master Scholarship**: Five merit-based scholarships per year for international students for master's degree in engineering
- **Incentive Scholarships**: For exchange students from partner universities

### Sweden
- **Chalmers IPOET Scholarships**: For international students pursuing Master's degree. Deadline: 15 Jan 2026
- **Swedish Institute Scholarships for Global Professionals**: Master's degree. Deadline: 15 Jan/25 Feb 2026
- **BTH Scholarships**: Blekinge Institute of Technology for Master's degree. Deadline: 15 Jan 2026

### France
- **Eiffel Scholarships**: French Government scholarships for Masters/PhD degree. Deadline: 8 Jan 2026

### United Kingdom
- **UCL Global Undergraduate Scholarships**: University College London. Deadline: 27 Apr 2026
- **UCL Global Masters Scholarships**: Deadline: 7 May 2026
- **Imperial College London PhD Scholarships in Chemical Engineering**: Fully funded
- **University of Manchester Engineering Scholarships**: For both domestic and international students at undergraduate level
- **University of Strathclyde Engineering Scholarships**: Wide selection for engineering students
- **QMUL Queen Mary Global Excellence Scholarships**: For international students
- **Arkwright Engineering Scholarships**: For high-achieving first-year engineering students
- **IET Awards and Scholarships**: Various undergraduate and postgraduate scholarships
- **IME Scholarships and Awards**: Mechanical engineering scholarships
- **QUEST Undergraduate Scholarships from ICE**: For civil engineering students
- **Women's Engineering Society Awards**: For women studying engineering
- **Nottingham Developing Solutions Scholarships**: Master's degree. Deadline: 15 April 2026
- **Commonwealth Master's and PhD Scholarships**: For Developing Commonwealth Countries

## NORTH AMERICA - Scholarships and Programs

### United States
**Top Universities with Need-Based Aid for International Students:**
- **MIT (Massachusetts Institute of Technology)**: Need-blind admissions for all applicants. Offers full need-based financial aid covering up to 100% of demonstrated need
- **Stanford University**: Offers need-based financial aid to international students
- **Caltech (California Institute of Technology)**: Need-based financial aid available

**Other US Scholarships:**
- **AFCEA San Diego Scholarship Program**: For engineering, mathematics, or science students in San Diego County, California
- **ASHRAE Undergraduate Engineering Scholarships**: For full-time students at accredited US institutions
- **ASME Mechanical Engineering Scholarships**: For all degree levels. Must be ASME members
- **Engineers Foundation of Ohio Engineering Scholarships**: For incoming engineering students in Ohio
- **IISE Scholarships and Fellowships**: For engineering students at IISE-accredited universities
- **National GEM Consortium Fellowships**: Graduate fellowships for PhD or master's level
- **National Society of Professional Engineers (NSPE) Scholarships**: For all degree levels
- **NEWWA Scholarships**: For engineering students in New England
- **Oregon NASA Space Grant Consortium**: STEM scholarships for Oregon students
- **SME Education Foundation Scholarships**: Various STEM scholarships
- **SWE Scholarship Program**: For women in engineering (Society of Women Engineers)
- **TMS Student Academic Scholarships**: For metallurgical engineering students

### Canada
- **University of Toronto International Scholarships**: Full 4-year scholarships for exceptional academic achievement and leadership
- **University of Waterloo International Scholarships**: 
  - International Student Entrance Scholarship: 20 scholarships valued at $10,000 each
  - Faculty of Engineering International Student Entrance Scholarships
- **Engineers Canada Scholarships**: One for undergraduate, two for graduate students

## OCEANIA - Scholarships and Programs

### Australia
- **Australia APEC Women in Research Fellowships**: Merit-based scholarships for research opportunities. Must be from eligible Asia-Pacific Economic Cooperation (APEC) countries

### New Zealand
- **Edna Waddell Undergraduate Scholarships**: For women in technology and engineering. Only for NZ citizens or permanent residents
- **Energy Education Trust Undergraduate and Honours Scholarships**: 15 scholarships for five participating NZ universities in science, economics, and engineering

## WORLDWIDE/ANYWHERE

- **Amelia Earhart Fellowship**: For women studying doctorate or PhD in aerospace and engineering programs
- **Schlumberger Foundation Faculty for the Future Fellowships**: Postgraduate scholarships for women in engineering, science, and STEM-related studies at universities worldwide

## Top Engineering Universities Worldwide

### For Computer Science/Engineering:
1. MIT (USA)
2. Stanford University (USA)
3. Carnegie Mellon University (USA)
4. University of California, Berkeley (USA)
5. Caltech (USA)
6. ETH Zurich (Switzerland)
7. University of Cambridge (UK)
8. University of Oxford (UK)
9. Imperial College London (UK)
10. National University of Singapore (Singapore)
11. Nanyang Technological University (Singapore)
12. TU Munich (Germany)
13. TU Delft (Netherlands)

## Important Notes

### For PCM + Computer Science Students:
- Eligible for all engineering branches, especially: Computer Science, Software Engineering, Electronics, Electrical, Mechanical, Aerospace, Civil Engineering
- Many universities offer specialized programs in AI/ML, Data Science, Cybersecurity, Game Engineering

### Application Tips:
1. Start early - many scholarship deadlines are 6-12 months before course start
2. Need-based aid (MIT, Stanford, Caltech) requires demonstrating financial need
3. Merit-based scholarships require excellent academic records and achievements
4. Some scholarships require working for sponsor companies after graduation
5. Germany offers low-cost education even without scholarships
6. Consider cost of living in addition to tuition fees

### Scholarship Types:
- **Full Scholarships**: Cover tuition + living expenses (MIT, Stanford need-based aid, some country-specific scholarships)
- **Partial Scholarships**: Cover tuition or part of expenses
- **Merit-Based**: Based on academic achievement
- **Need-Based**: Based on financial circumstances
- **Country-Specific**: For students from particular regions/countries
- **Gender-Specific**: Especially for women in engineering

## Next Steps for Students:
1. Research specific university requirements
2. Prepare for standardized tests (SAT, ACT for US; other requirements for different countries)
3. Build strong academic profile and extracurricular activities
4. Prepare application materials early
5. Apply to multiple scholarships to increase chances
6. Check visa requirements for each country
